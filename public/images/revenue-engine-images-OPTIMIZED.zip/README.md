# REVENUE ENGINE — OPTIMIZED IMAGE ASSETS

All 35 images optimized for web. Total size: 7.4MB (down from 49MB).
No single file exceeds 500KB. GitHub upload will work cleanly.

NOTE: Some OMAD files were converted from PNG to JPG for better compression.
File names below are the FINAL correct names.

## TARGET PATHS ON GITHUB

### public/images/founders/
- alex-sadik.jpg
- shawan-young.jpg

### public/images/work/omad/
- omad-automotive-oil-gas.jpg
- omad-booth-display.jpg
- omad-booth-tmk-partnership.jpg
- omad-booth-uzbekistan.jpg
- omad-brochure-spread.jpg
- omad-canada-uzbek-flags.jpg
- omad-central-asia-corridor.webp
- omad-central-asia-map.jpg
- omad-cover.webp
- omad-localboost-platform-mockup.webp
- omad-mobile-screens.webp
- omad-strategic-briefing.jpg
- omad-tmk-ceremony.jpg

### public/images/work/road-ready/
- road-ready-hero.jpg

### public/images/work/localboost/
- localboost-built-for-local.jpg
- localboost-drive-leads.jpg
- localboost-platform-3d.jpg
- localboost-track-lead.jpg

### public/images/mockups/
- crm-lead-scoring-dual-laptops.jpg
- funnel-charts.jpg
- lead-tracking-phone-dashboard.jpg
- pulse-dashboard-purple.jpg
- saas-dashboard-purple.jpg

### public/images/stock/ (12 files)
- All stock photos

Total: 35 files
